#https://keras.io/guides/functional_api/

#https://blog.keras.io/building-autoencoders-in-keras.html
#https://maelfabien.github.io/deeplearning/autoencoder/#visualize-the-output


import os
os.environ["CUDA_VISIBLE_DEVICES"]="-1"
os.environ['PYTHONHASHSEED'] = '0'
os.environ['KERAS_BACKEND'] = 'tensorflow'
import copy
import random
random.seed(0)
import numpy as np
np.random.seed(0)
#import tensorflow.compat.v1 as tf

#from tensorflow import set_random_seed
#tf.set_random_seed(1)

import numpy as np # linear algebra
import pandas as pd # data processing, CSV file I/O (e.g. pd.read_csv)
from sklearn.model_selection import train_test_split
from sklearn.metrics import roc_auc_score
from sklearn.manifold import TSNE
import pydotplus
import tensorflow as tf
from keras.utils import plot_model
#from keras.utils.vis_utils import plot_model
from keras import backend as k
import tensorflow as tf
from keras.layers import Reshape, Lambda
from sklearn.metrics import classification_report
from keras.preprocessing.text import Tokenizer
from keras.preprocessing.sequence import pad_sequences
from keras.layers import LSTM, Conv1D, MaxPooling1D, Dropout
from keras.utils.np_utils import to_categorical
from keras.layers import Dense, Input, Flatten
from keras.layers import GlobalAveragePooling1D, Embedding
from keras.models import Model
from keras.callbacks import EarlyStopping
from keras.layers import Input, Embedding, LSTM, Dense
from keras.layers.convolutional import Conv2D
from keras.layers.pooling import MaxPooling2D
from keras.layers.merge import concatenate
#from keras.utils import plot_modelyer_perceptron_graph.png')
from numpy import linalg as LA
from sklearn.metrics import classification_report, confusion_matrix
from keras.layers import Layer
import keras.backend as K
import re, operator
from nltk.corpus import stopwords

from hyperopt import fmin, tpe, hp, STATUS_OK, Trials, space_eval
import pandas as pd
import numpy as np
from ast import literal_eval as le
from sklearn.metrics import classification_report

#import sampleOrg3 as so
#import result2 as resCal

from CONTEXT import Context

REPLACE_BY_SPACE_RE = re.compile('[/(){}\[\]\|,;]')
BAD_SYMBOLS_RE = re.compile('[^0-9a-z #+_]')
#STOPWORDS = set(stopwords.words('english'))

#import modules as mdl

targetModel="repo/target_1:1.csv"
ensembleModel="repo/ensemble_1:1.csv"
extent=100
modelname="repo/completemodel.h5"

from sklearn.model_selection import train_test_split
def define_model(length, vocab_size):
	# channel 1
	inputs1 = Input(shape=(length,))
	embedding1 = Embedding(vocab_size, 100)(inputs1)
	conv1 = Conv1D(filters=32, kernel_size=4, activation='relu')(embedding1)
	drop1 = Dropout(0.5)(conv1)
	pool1 = MaxPooling1D(pool_size=2)(drop1)
	flat1 = Flatten()(pool1)
	# channel 2
	inputs2 = Input(shape=(length,))
	embedding2 = Embedding(vocab_size, 100)(inputs2)
	conv2 = Conv1D(filters=32, kernel_size=6, activation='relu')(embedding2)
	drop2 = Dropout(0.5)(conv2)
	pool2 = MaxPooling1D(pool_size=2)(drop2)
	flat2 = Flatten()(pool2)
	# channel 3
	inputs3 = Input(shape=(length,))
	embedding3 = Embedding(vocab_size, 100)(inputs3)
	conv3 = Conv1D(filters=32, kernel_size=8, activation='relu')(embedding3)
	drop3 = Dropout(0.5)(conv3)
	pool3 = MaxPooling1D(pool_size=2)(drop3)
	flat3 = Flatten()(pool3)
	# merge
	merged = concatenate([flat1, flat2, flat3])
	# interpretation
	dense1 = Dense(10, activation='relu')(merged)
	outputs = Dense(1, activation='sigmoid')(dense1)
	model = Model(inputs=[inputs1, inputs2, inputs3], outputs=outputs)
	# compile
	model.compile(loss='binary_crossentropy', optimizer='adam', metrics=['accuracy'])
	# summarize
	#print(model.summary())
	#plot_model(model, show_shapes=True, to_file='multichannel.png')
	return model
	
class GradReverse(tf.keras.layers.Layer):
    def __init__(self):
        super().__init__()

    def call(self, x):
        return grad_reverse(x)

@tf.custom_gradient
def grad_reverse(x):
    y = tf.identity(x)
    def custom_grad(dy):
        return -dy
    return y, custom_grad

def ende_model(length, vocab_size):
	inputs1 = Input(shape=(length,))
	encoded = Dense(128, activation='relu')(inputs1)
	encoded = Dense(64, activation='relu')(encoded)
	encoded = Dense(32, activation='relu')(encoded)

	decoded = Dense(64, activation='relu')(encoded)
	decoded = Dense(128, activation='relu')(decoded)
	#att_out=attention()(decoded)
	decoded = Dense(1, activation='sigmoid')(decoded)
	autoencoder = Model(inputs1, decoded)
	#print(autoencoder.summary())
	#plot_model(autoencoder, show_shapes=True, to_file='ende.png')
	return autoencoder

class attention(Layer):
    def __init__(self,**kwargs):
        super(attention,self).__init__(**kwargs)

    def build(self,input_shape):
        self.W=self.add_weight(name="att_weight",shape=(input_shape[-1],1),initializer="normal")
        self.b=self.add_weight(name="att_bias",shape=(input_shape[1],1),initializer="zeros")        
        super(attention, self).build(input_shape)

    def call(self,x):
        et=K.squeeze(K.tanh(K.dot(x,self.W)+self.b),axis=-1)
        at=K.softmax(et)
        at=K.expand_dims(at,axis=-1)
        output=x*at
        return K.sum(output,axis=1)

    def compute_output_shape(self,input_shape):
        return (input_shape[0],input_shape[-1])

    def get_config(self):
        return super(attention,self).get_config()


class Attention(tf.keras.Model):
    def __init__(self, units):
        super(Attention, self).__init__()
        self.W1 = tf.keras.layers.Dense(units)
        self.W2 = tf.keras.layers.Dense(units)
        self.V = tf.keras.layers.Dense(1)
 
    def call(self, features, hidden):
        # hidden shape == (batch_size, hidden size)
        # hidden_with_time_axis shape == (batch_size, 1, hidden size)
        # we are doing this to perform addition to calculate the score
        hidden_with_time_axis = tf.expand_dims(hidden, 1)

        # score shape == (batch_size, max_length, 1)
        # we get 1 at the last axis because we are applying score to self.V
        # the shape of the tensor before applying self.V is (batch_size, max_length, units)
        score = tf.nn.tanh(
            self.W1(features) + self.W2(hidden_with_time_axis))
        
        # attention_weights shape == (batch_size, max_length, 1)
        attention_weights = tf.nn.softmax(self.V(score), axis=1)

        # context_vector shape after sum == (batch_size, hidden_size)
        context_vector = attention_weights * features
        context_vector = tf.reduce_sum(context_vector, axis=1)
 
        return context_vector, attention_weights


def modified_attention(length, vocab_size):
	inputs1 = Input(shape=(length,), dtype='int32')#, name='main_input')
	#x = Embedding(output_dim=output_dim, input_dim=input_dim, weights=[embedding_matrix2], input_length=input_sequence_length)(main_input)
	embedding1 = Embedding(vocab_size, 100)(inputs1)	
	x = Conv1D(32, 5)(embedding1)
	# MaxPool divides the length of the sequence by 5
	x = MaxPooling1D(5)(x)
	x = Dropout(0.2)(x)
	
	decoded_x = Conv1D(32, 5)(x)
	decoded_x = MaxPooling1D(5)(decoded_x)
	decoded_x = Dropout(0.2)(decoded_x)
	decoded_x=Reshape((32, 4))(decoded_x)
	decoded_x=Dense(24, activation="sigmoid")(decoded_x)
	decoded_x=Reshape((24, 32))(decoded_x)

	#x= concatenate([x, decoded_x, x])
	att_out, ss=Attention(10)(x, decoded_x)
	#flat = Flatten()(x)
	
	decoded_x = Dense(32, activation="relu")(att_out)
	#att_out=attention()(decoded_x)
	decoded = Dense(1, activation='sigmoid', name="output")(decoded_x)
	autoencoder = Model(inputs1, decoded)
	#print(autoencoder.summary())
	#plot_model(autoencoder, show_shapes=True, to_file='ende.png')
	return autoencoder

def ende_model1(length, vocab_size):
	inputs1 = Input(shape=(length,), dtype='int32')#, name='main_input')
	#x = Embedding(output_dim=output_dim, input_dim=input_dim, weights=[embedding_matrix2], input_length=input_sequence_length)(main_input)
	embedding1 = Embedding(vocab_size, 100)(inputs1)	
	x = Conv1D(32, 5)(embedding1)
	# MaxPool divides the length of the sequence by 5
	x = MaxPooling1D(5)(x)
	x = Dropout(0.2)(x)
	
	decoded_x = Conv1D(32, 5)(x)
	decoded_x = MaxPooling1D(5)(decoded_x)
	decoded_x = Dropout(0.2)(decoded_x)
	decoded_x=Reshape((32, 4))(decoded_x)
	decoded_x=Dense(24, activation="sigmoid")(decoded_x)
	decoded_x=Reshape((24, 32))(decoded_x)

	x= concatenate([x, decoded_x, x])
	att_out=attention()(x)
	#flat = Flatten()(x)
	
	decoded_x = Dense(32, activation="relu")(att_out)
	#att_out=attention()(decoded_x)
	decoded = Dense(1, activation='sigmoid', name="output")(decoded_x)
	autoencoder = Model(inputs1, decoded)
	#print(autoencoder.summary())
	#plot_model(autoencoder, show_shapes=True, to_file='ende.png')
	return autoencoder


def ende_model2(length, vocab_size):
	inputs1 = Input(shape=(length,), dtype='int32')#, name='main_input')
	#x = Embedding(output_dim=output_dim, input_dim=input_dim, weights=[embedding_matrix2], input_length=input_sequence_length)(main_input)
	embedding1 = Embedding(vocab_size, 100)(inputs1)	
	x = Conv1D(32, 5)(embedding1)
	# MaxPool divides the length of the sequence by 5
	x = MaxPooling1D(5)(x)
	x = Dropout(0.2)(x)
	decoded_x = Conv1D(32, 5)(x)
	decoded_x = MaxPooling1D(5)(decoded_x)
	decoded_x = Dropout(0.2)(decoded_x)
	att_out=attention()(decoded_x)
	#flat = Flatten()(x)
	decoded_x = Dense(32, activation="relu")(att_out)
	#att_out=attention()(decoded_x)
	decoded = Dense(1, activation='sigmoid', name="output")(decoded_x)


	#inputs1 = Input(shape=(length,), dtype='int32')#, name='main_input')
	#x = Embedding(output_dim=output_dim, input_dim=input_dim, weights=[embedding_matrix2], input_length=input_sequence_length)(main_input)
	embedding1 = Embedding(vocab_size, 100)(inputs1)	
	x1 = Conv1D(32, 5)(embedding1)
	# MaxPool divides the length of the sequence by 5
	x1 = MaxPooling1D(5)(x1)
	x1 = Dropout(0.2)(x1)
	decoded_x1 = Conv1D(32, 5)(x1)
	decoded_x1 = MaxPooling1D(5)(decoded_x1)
	decoded_x1 = Dropout(0.2)(decoded_x1)
	att_out1=attention()(decoded_x1)
	#flat = Flatten()(x)
	
	decoded_x1 = Dense(32, activation="relu")(att_out1)
	decoded1 = Dense(1, activation='sigmoid', name="output1")(decoded_x1)

	autoencoder = Model(input=inputs1, output= [decoded, decoded1])
	#print(autoencoder.summary())
	#plot_model(autoencoder, show_shapes=True, to_file='ende.png')
	return autoencoder
	

def main_model(length, vocab_size):
	inputs1 = Input(shape=(length,))#, dtype='int32')#, name='main_input')
	#x = Embedding(output_dim=output_dim, input_dim=input_dim, weights=[embedding_matrix2], input_length=input_sequence_length)(main_input)
	embedding1 = Embedding(vocab_size, 100)(inputs1)#; print ("shapes embed ", embedding1.shape); input("enter")
	embedding1=Context(out_N=100)(embedding1)#; print ("shapes embed ", embedding1.shape); input("enter")
	x = Conv1D(32, 5)(embedding1)
	# MaxPool divides the length of the sequence by 5
	x = MaxPooling1D(5)(x)
	x = Dropout(0.4)(x)
	decoded_x = Conv1D(32, 5)(x)
	decoded_x = MaxPooling1D(5)(decoded_x)
	decoded_x = Dropout(0.4)(decoded_x)
	att_out=attention()(decoded_x)
	#flat = Flatten()(x)
	decoded_x = Dense(32, activation="relu")(att_out)
	#att_out=attention()(decoded_x)
	r = grad_reverse(decoded_x)	
	decoded_rev = Dense(1, activation='sigmoid', name="output_rev")(r)


	embedding2 = Embedding(vocab_size, 100)(inputs1)
	embedding2=Context(out_N=100)(embedding2)	
	x1 = Conv1D(32, 5)(embedding2)
	# MaxPool divides the length of the sequence by 5
	x1 = MaxPooling1D(5)(x1)
	x1 = Dropout(0.4)(x1)
	decoded_x1 = Conv1D(32, 5)(x1)
	decoded_x1 = MaxPooling1D(5)(decoded_x1)
	decoded_x1 = Dropout(0.2)(decoded_x1)
	att_out1=attention()(decoded_x1)
	#flat = Flatten()(x)
	
	decoded_x1 = Dense(32, activation="relu")(att_out1)
	decoded_pred = Dense(1, activation='sigmoid', name="output_pred")(r)
	
	main_decoder= concatenate([r, decoded_x1])
	decoded_tag = Dense(1, activation='sigmoid', name="output_tag")(main_decoder)
	
	autoencoder = Model(inputs1, decoded_tag)#decoded_pred, decoded_pred, decoded_tag])
	print(autoencoder.summary())
	plot_model(autoencoder, show_shapes=True, to_file='repo/ende.png')
	return autoencoder
	

def trainTestBalance(df):
	lis=df["class"].tolist()
	m, n= lis.count(1), lis.count(0)
	for i in range(100):
		df=df.sample(frac=1)
	N=int(0.8*m)
	dfTr=pd.concat([ df[ ( (df["class"]==1) ) ][:N], df[ ( (df["class"]==0) ) ][:N]  ])
	dfTs=pd.concat([ df[ ( (df["class"]==1) ) ][N:m], df[ ( (df["class"]==0) ) ][N:m]  ])
	for i in range(100):
		dfTr=dfTr.sample(frac=1)
		dfTs=dfTs.sample(frac=1)
	x_train, y_train=dfTr["text"].values, dfTr["class"].values
	x_test, y_test=dfTs["text"].values, dfTs["class"].values
	#print (type(x_train), x_train.shape, type(y_test), y_test.shape)
	return x_train, x_test, y_train, y_test
	

def trainTestData(**kwargs):
	#update
	srcFileName=kwargs["srcFileName"]

	MAX_NB_WORDS = 20000
	MAX_SEQUENCE_LENGTH = 128

	df = pd.read_csv(srcFileName, sep=",",encoding='latin-1')	
	x_train, x_test, y_train, y_test=trainTestBalance(df[["text", "class"]])
	test_text=copy.copy(x_test)
	#x_train, x_test,y_train, y_test = train_test_split(df['text'],df["class"],test_size=0.2,train_size=0.8)
	
	x_train = x_train.astype(str)
	x_test = x_test.astype(str)

	# finally, vectorize the text samples into a 2D integer tensor
	tokenizer = Tokenizer(nb_words=MAX_NB_WORDS, char_level=False)
	tokenizer.fit_on_texts(x_train)
	tokenizer.fit_on_texts(x_test)
	sequences1 = tokenizer.texts_to_sequences(x_train)
	sequences_test1 = tokenizer.texts_to_sequences(x_test)

	# pad sequences with 0s
	x_train = pad_sequences(sequences1, maxlen=MAX_SEQUENCE_LENGTH)
	
	x_test = pad_sequences(sequences_test1, maxlen=MAX_SEQUENCE_LENGTH)
	print ("going out of traintest", x_train.shape, x_test.shape,y_train.shape, y_test.shape)
	c=0
	for i in y_test:
		if i == 1:
			c=c+1
	print(c)
	#print ("printing values ", x_train.shape, y_train.shape, x_test.shape, y_test.shape); input("enter")
	return x_train, x_test, y_train, y_test, test_text

def bestWeight(params):	
	#print ("hello reached here"); input("enter")

	kwargs={"srcFileName":"hurricane_processed.csv"}
	x_train, x_test,y_train, y_test, test_text =trainTestData(**kwargs)
	
	model = main_model(params["MAX_SEQUENCE_LENGTH"], params["vocab_size"])
	
	epochs=params["epochs"]
	model.compile(optimizer='adam', loss='binary_crossentropy', metrics=['accuracy'])
	his=model.fit(x_train, y_train, epochs=epochs, validation_split=0.3, verbose=2)
	
	##dfstats
	dfStats=pd.DataFrame()
	dfStats["loss"]=his.history["loss"]
	dfStats["val_loss"]=his.history["val_loss"]
	dfStats.to_csv("repo/dfStats_cntx_"+str(epochs)+".csv", index=False)	
	
	mnValLoss=min(his.history["val_loss"])
		
	return mnValLoss

space={"MAX_SEQUENCE_LENGTH":hp.choice("MAX_SEQUENCE_LENGTH", [128]), "vocab_size":hp.choice("vocab_size", [20000]), "output_word_dim":hp.choice("output_word_dim", [200]), "input_sequence_length":hp.choice("input_sequence_length", [150]), "no_of_filters":hp.choice("no_of_filters", [64]), "filter_size":hp.choice("filter_size", [5]), "maxPool_size":hp.choice("maxPool_size", [5]), "dropout_fraction":hp.choice("dropout_fraction", [0.2]), "epochs":hp.choice("epochs", [100, 200, 300])}

def f(params):
	val_loss = bestWeight(params)
	return {'loss': val_loss, 'status': STATUS_OK}

trials = Trials()
best = fmin(f, space, algo=tpe.suggest, max_evals=20, trials=trials)
print ('best:')
print ("best",type(best), best, space_eval(space, best))
















